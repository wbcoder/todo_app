import React, { useState } from 'react';

function ToDoList(){

    const [tasks, setTasks] = useState([]);
    const [newTask, setNewTask] = useState("");

    function handleInputChange(event){
        setNewTask(event.target.value);
    }

    function addTask(){
        if(newTask.trim() !== ""){
            setTasks(t => [...t, newTask]);
            setNewTask("");
        } 
    }
     
    function deleteTask(index){ 
        const updatedTasks= tasks.filter((_, i) => i !==index);
        setTasks(updatedTasks);
    }

    function editTask(index){
        
    }

    function moveTaskUp(index){
        if(index > 0){
            const updatedTasks = [...tasks];
            [updatedTasks[index], updatedTasks[index -1]] =
            [updatedTasks[index -1], updatedTasks[index]];
            setTasks(updatedTasks);
        }
    }

    function moveTaskDown(index){
        if(index < tasks.length - 1){
            const updatedTasks = [...tasks];
            [updatedTasks[index], updatedTasks[index + 1]] =
            [updatedTasks[index + 1], updatedTasks[index]];
            setTasks(updatedTasks);
        }
    }

 return(

<div id="main_wrap">
<div className="to_do_list">
    <h1> CX TO DO List </h1>
    <hr />
    <div className="main_input">
        <input type="text" placeholder="Enter your task....." 
        value={newTask}
        onChange={handleInputChange}/>

        <button className="add_task_btn"
        onClick={addTask}><i className="fas fa-plus"></i> </button>
    </div>
    <hr />
        <div className="task_wrapper">
            <ol>
                {tasks.map((task, index) =>
                <li key={index}>
                    <span className="text">{task}</span>
                    <hr/>
                    <div className="btn_set">
                        <button className="trash_btn"
                        onClick={() => deleteTask(index)}> <i class="fa-solid fa-trash-can"></i> </button>
                        <button className="move_up"
                        onClick={() => moveTaskUp(index)}><i class="fa-solid fa-arrow-up"></i></button>
                        <button className="move_down"
                        onClick={() => moveTaskDown(index)}><i class="fa-solid fa-arrow-down"></i></button>
                    </div>
                </li>)}
            </ol>
        </div>
    </div>
</div>);
}

export default ToDoList